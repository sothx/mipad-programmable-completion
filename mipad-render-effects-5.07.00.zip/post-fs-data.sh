MODDIR=${0%/*}
. "$MODDIR"/util_functions.sh